-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Versión del servidor: 10.4.17-MariaDB
-- Versión de PHP: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
-- --------------------------------------------------------

CREATE TABLE 'psicopelis' (
  'id' int(3) NOT NULL,
  'titol' varchar(49) DEFAULT NULL,
  'director' varchar(28) DEFAULT NULL,
  'any' int(4) DEFAULT NULL,
  'pais' varchar(19) DEFAULT NULL,
  'puntuacio' int(2) DEFAULT NULL,
  'observacions' varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `psicopelis_txt_3`
--

INSERT INTO 'psicopelis' ('id', 'titulo', 'director', 'ano', 'pais', 'puntuacion', 'sinopsis', 'comentario') VALUES
(1,'El principe de las mareas','Barbra Streisand', 1991,'USA', 8, '', ''),
(2,'Las niñas','Pilar Palomero' 2020,'SPAIN', 2, '', ''),
(3,'Alguien voló sobre el nido del cuco','Milos Forman', 1975,'USA', 10, '', ''),
(4,'La joven de la perla','Peter Webber', 2003,'UK', 9, '', ''),
(5,'Nueve reinas','Fabián Bielinsky', 2000,'ARGENTINA', 4, '', ''),
(6,'Funny Games','Michael Haneke', 2007,'USA', 5, '', ''),
(7,'Desayuno en Plutón','Neil Jordan', 2005,'IRELAND', 9, '', ''),
(8,'Llámame Peter','Stephen Hopkins', 2004,'USA', 10, '', ''),
(9,'En tierra de nadie','Danis Tanovic', 2001,'BOSNIA-HERZEGOVINA', 9, '', ''),
(10,'El secreto de Vera Drake','Mike Leigh', 2004,'UK', 7, '', ''),
(11,'Sophie Scholl Los últimos días','Marc Rothemund', 2005,'GERMANY', 3, '', ''),
(12,'Pelle el conquistador','Bille August', 1987,'DENMARK', 7, '', ''),
(13,'Balzac y la joven costurera china','Dai Sijie', 2002,'CHINA', 8, '', ''),
(14,'Tsotsi','Gavin Hood', 2005,'SURÀFRICA', 8, '', ''),
(15,'Memento','Christopher Nolan', 2000,'USA', 8,''),
(16,'No sos vos soy yo','Juan Taratuto', 2004,'ARGENTINA', 4, '', ''),
(17,'En la cama','Matías Bize', 2005,'XILE', 8, '', ''),
(18,'Un funeral de muerte','Frank Oz', 2007,'UK', 8, '', ''),
(19,'Entreacto','Manuel Cussó-Ferrer', 1989,'SPAIN', 2, '', ''),
(20,'El viaje de Chihiro','Hayao Miyazaki', 2001,'JAPAN', 4, '', ''),
(21,'Un tipo corriente','Eduardo Milewicz', 2001,'ARGENTINA', 10, '', ''),
(22,'Take Shelter','Jeff Nichols', 2011,'USA', 10, '', ''),
(23,'Como agua para chocolate','Alfonso Arau', 1992,'MEXICO', 10, '', ''),
(24,'El hombre elefante','David Lynch', 1980,'USA', 4, '', ''),
(25,'Nostalgia','Vanessa Batista', 2019,'SPAIN', 8, '', ''),
(26,'Bajo sospecha','Stephen Hopkins', 2000,'USA', 7, '', ''),
(27,'El pianista','Roman Polanski', 2002,'UK', 8, '', ''),
(28,'Flores rotas','Jim Jarmusch', 2005,'USA', 5, '', ''),
(29,'Buffalo 66','Vincent Gallo', 1999,'USA', 5, '', ''),
(30,'La escafandra y la mariposa','Julian Schnabel', 2007,'FRANCE', 7, '', ''),
(31,'Factótum','Bent Hamer', 2005,'NORUEGA', 8, '', ''),
(32,'Ciudad de Dios','Fernando Meirelles', 2002,'BRASIL', 9, '', ''),
(33,'Bailar en la oscuridad','Lars von Trier', 2000,'DENMARK', 0, 0, 7, '', ''),
(34,'El señor Ibrahim y las flores del Corán','François Dupeyron', 2003,'FRANCE', 3, '', ''),
(35,'Mi hermosa lavandería','Stephen Frears', 1985,'UK', 2, '', ''),
(36,'El cielo protector','Bernardo Bertolucci', 1989,'UK',  4, '', ''),
(37,'Secretos y mentiras','Mike Leigh', 1996,'UK', 5, '', ''),
(38,'Las mujeres de verdad tienen curvas','Patricia Cardoso', 2002,'USA', 7, '', ''),
(39,'Adiós a mi concubina','Chen Kaige', 1993,'CHINA', 10, '', ''),
(40,'Cinema Paradiso','Giuseppe Tornatore', 1988,'ITALY', 4, '', ''),
(41,'Tigre y dragón','Ang Lee', 2000,'TAIWÀN', 5, '', ''),
(42,'Y tu mamá también','Alfonso Cuarón', 2001,'MÈXIC',5, '', ''),
(43,'Un lugar en el mundo','Adolfo Aristarain', 1992,'ARGENTINA', 5, '', ''),
(44,'Crimen ferpecto','Álex de la Iglesia', 2004,'SPAIN', 7, '', ''),
(45,'El espinazo del diablo','Guillermo del Toro', 2001,'SPAIN', 9, '', ''),
(46,'Luna de Avellaneda','Juan José Campanella', 2004,'ARGENTINA', 9, '', ''),
(47,'Historias del Kronen','Montxo Armendáriz', 1995,'SPAIN', 4, '', ''),
(48,'Amores perros','Alejandro González Iñárritu', 2000,'MÈXIC', 3, '', ''),
(49,'El viaje a ninguna parte','Fernando Fernán-Gómez', 1986,'SPAIN', 5, '', ''),
(50,'Roma','Adolfo Aristarain', 2004,'ARGENTINA', 5, '', ''),
(51,'La vida de nadie','Eduard Cortés', 2003,'SPAIN', 4, '', ''),
(52,'Guantanamera','Tomás G. Alea', 1995,'CUBA', 7, '', ''),
(53,'El viaje de Carol','Imanol Uribe', 2002,'SPAIN', 6, '', ''),
(54,'Tiovivo c. 1950','José Luis Garci', 2004,'SPAIN', 6, '', ''),
(55,'El mismo amor, la misma lluvia','Juan José Campanella', 1999,'ARGENTINA', 6, '', ''),
(56,'Celos','Vicente Aranda', 1999,'SPAIN', 10, '', ''),
(57,'La ardilla roja','Julio Medem', 1993,'SPAIN', 3, '', ''),
(58,'El abrazo partido','Daniel Burman', 2003,'ARGENTINA', 3, '', ''),
(59,'Bajarse al moro','Fernando Colomo', 1988,'SPAIN', 5, '', ''),
(60,'Historia de un beso','José Luis Garci', 2002,'SPAIN', 10, '', ''),
(61,'La flaqueza del bolchevique','Manuel Martín Cuenca', 2003,'SPAIN', 9, '', ''),
(62,'Sobreviviré','Alfonso Albacete', 1999,'SPAIN', 6, '', ''),
(63,'En la ciudad','Cesc Gay', 2003,'SPAIN', 2, '', ''),
(64,'La virgen de los sicarios','Barbet Schroeder', 1999,'COLOMBIA', 2, '', ''),
(65,'El último emperador','Bernardo Bertolucci', 1987,'UK', 3, '', ''),
(66,'Love actually','Richard Curtis', 2003,'UK', 5, '', ''),
(67,'Tres colores: Azul','Krzysztof Kieslowski', 1993,'POLAND', 10, '', ''),
(68,'Elizabeth','Shekhar Kapur', 1998,'UK', 7, '', ''),
(69,'Quiero ser como Beckham','Gurinder Chadha', 2002,'UK', 3, '', ''),
(70,'El pacto de los lobos','Christophe Gans', 2001,'FRANCE', 8, '', ''),
(71,'Indochina','Régis Wargnier', 1992,'FRANCE', 8, '', ''),
(72,'The Commitments','Alan Parker', 1991,'UK', 7, '', ''),
(73,'El marido de la peluquera','Patrice Leconte', 1990,'FRANCE', 8, '', ''),
(74,'Le divorce','James Ivory', 2003,'USA', 7, '', ''),
(75,'Una historia del Bronx','Robert De Niro', 1993,'USA', 5, '', ''),
(76,'Amor en conserva','David Miller', 1950,'USA', 4, '', ''),
(77,'La defensa Luzhin','Marleen Gorris', 2001,'UK', 5, '', ''),
(78,'Coraje de mujer','Karen Arthur', 1997,'USA', 6, '', ''),
(79,'Carros de fuego','Hugh Hudson', 1981,'UK', 8, '', ''),
(80,'Armas de mujer','Mike Nichols', 1988,'USA', 10, '', ''),
(81,'Sr. Y Sra. Smith','Doug Liman', 2005,'USA', 3, '', ''),
(82,'Wall Street','Oliver Stone', 1987,'USA', 2, '', ''),
(83,'Un puente hacia Terabithia','Gabor Csupo', 2007,'USA', 2, '', ''),
(84,'Un día inolvidable','Michael Hoffman', 1996,'USA', 2, '', ''),
(85,'La Spagnola','Steve Jacobs', 2001,'AUSTRALIA', 2, '', ''),
(86,'Sentido y sensibilidad','Rodney Bennett', 1981,'UK', 8, '', ''),
(87,'Madame Bovary','Tim Fywell', 2000,'USA', 9, '', ''),
(88,'Todo sobre mi madre','Pedro Almodóvar', 1999,'SPAIN', 6, '', ''),
(89,'Los límites del silencio','Tom McLoughlin', 2001,'USA', 4, '', ''),
(90,'Un domingo cualquiera','Oliver Stone', 1999,'USA', 10, '', ''),
(91,'EL libro negro','Paul Verhoeven', 2006,'HOLAND', 2, '', ''),
(92,'La decisión de Sophie','Alan J. Pakula', 1982,'USA', 6, '', ''),
(93,'Lunas de hiel','Roman Polanski', 1992,'UK', 10, '', ''),
(94,'The wall','Alan Parker', 1982,'UK', 10, '', ''),
(95,'Ragtime','Milos Forman', 1981,'USA', 10, '', ''),
(96,'The door in the floor','Tod Williams', 2004,'USA', 3, '', ''),
(97,'Good morning Babilonia','Paolo Taviani', 1986,'ITALY', 10, '', ''),
(98,'Flower Power (como una regadera)','Joel Hershman', 2000,'UK', 7, '', ''),
(99,'Saw II','Darren Lynn Bousman', 2005,'USA', 10, '', ''),
(100,'El chico que conquistó Hollywood','Brett Morgen,', 2002,'USA', 2, '', ''),
(101,'Deseando amar','Wong Kar-Wai', 2000,'HONG-HONG', 9, '', ''),
(102,'Promises','Justine Shapiro', 2001,'ISRAEL', 4, '', ''),
(103,'Evelyn','Bruce Beresford', 2002,'IRELAND', 4,''),
(104,'Mr. Magorium y su tienda mágica','Zach Helm', 2007,'USA', 6, '', ''),
(105,'Un plan brillante','Michael Radford', 2007,'UK', 6, '', ''),
(106,'West side story','Robert Wise', 1961,'USA', 6, '', ''),
(107,'En el valle de Elah','Paul Haggis', 2007,'USA', 2, '', ''),
(108,'Los siete magníficos','John Sturges', 1960,'USA', 5, '', ''),
(109,'El viaje del emperador','Luc Jacquet', 2005,'FRANCE', 3, '', ''),
(110,'Bangkok dangerous','Oxide Pang Chun', 2008,'USA', 7, '', ''),
(111,'Michael Clayton','Tony Gilroy', 2007,'USA', 3, '', ''),
(112,'La gran evasión','John Sturges', 1962,'USA', 10, '', ''),
(113,'Tomates verdes fritos','Jon Avnet', 1991,'USA', 5, '', ''),
(114,'Paris, Texas','Wim Wenders', 1984,'Usa', 8, '', ''),
(115,'Los amigos de Peter','Kenneth Branagh', 1992,'UK', 4, '', ''),
(116,'Mrs. Henderson','Stephen Frears', 2005,'UK', 7, '', ''),
(117,'El imperio de los sentidos','Nagisa Oshima', 1976,'JAPAN', 8, '', ''),
(118,'Confidence','James Foley', 2003,'USA', 2,''),
(119,'The nanny diaries (Diario de una niñera)','Robert Pulcini', 2007,'USA', 6, '', ''),
(120,'Aflicción','Paul Schrader', 1998,'USA', 9, '', ''),
(121,'El hombre del tren','Patrice Leconte', 2002,'FRANCE', 4, '', ''),
(122,'El maquinista','Brad Anderson', 2004,'SPAIN', 9, '', ''),
(123,'Los niños de Huang Shi','Roger Spottiswoode', 2008,'CHINA', 7, '', ''),
(124,'Shaft The return','John Singleton', 2000,'USA', 4, '', ''),
(201,'Crash','David Cronenberg', 1996,'CANADA', 3, '', ''),
(202,'Confidencias','Luchino Visconti', 1974,'ITALY', 10, '', ''),
(203,'Solaris','Steven Soderbergh', 2002,'USA', 9, '', ''),
(204,'Minority report','Steven Spielberg', 2002,'USA', 4, '', ''),
(205,'Injusta condena','Bradley Battersby', 2000,'USA', 7, '', ''),
(206,'Apocalypse now','Francis Ford Coppola', 1979,'USA', 8, '', ''),
(207,'Mystic river','Clint Eastwood', 2003,'USA', 2, '', ''),
(208,'Una relación privada','Fréderic Fonteyne', 2000,'FRANCE', 2, '', ''),
(209,'Smoke','Wayne Wang', 1995,'USA', 6, '', ''),
(210,'Tierras de penumbra','Richard Attenborough', 1993,'UK', 10, '', ''),
(211,'Soldados de salamina','David Trueba', 2003,'SPAIN', 2, '', ''),
(212,'Full monty','Peter Cattaneo', 1997,'UK', 5, '', ''),
(213,'El club de la lucha','David Fincher', 1999,'USA', 10, '', ''),
(214,'Lantana','Ray Lawrence', 2001,'AUSTRALIA', 7, '', ''),
(215,'Martín hache','Adolfo Aristarain', 1997,'ARGENTINA', 8, '', ''),
(216,'Femme fatale','Brian De Palma', 2002,'USA', 9, '', ''),
(217,'Orgullo y prejuicio','Joe Wright', 2005,'UK', 9, '', ''),
(218,'Carne trémula','Pedro Almodóvar', 1997,'SPAIN', 4, '', ''),
(219,'Ali','Michael Mann', 2001,'USA', 2, '', ''),
(220,'The queen','Stephen Frears', 2006,'UK', 2, '', ''),
(221,'Traffic','Steven Soderbergh', 2000,'USA', 4, '', ''),
(222,'Diarios de motocicleta','Walter Salles', 2003,'ARGENTINA', 9, '', ''),
(223,'Europa','Lars von Trier', 1991,'DENMARK', 9, '', ''),
(224,'En el nombre del padre','Jim Sheridan', 1993,'IRELAND', 7, '', ''),
(225,'El mercader de Venecia','Michael Radford', 2004,'UK', 8, '', ''),
(226,'El cuarto àngel','John Irvin', 2002,'UK', 10, '', ''),
(227,'In & Out','Frank Oz', 1997,'USA', 9, '', ''),
(228,'El cuarto protocolo','John MacKenzie', 1987,'UK', 2, '', ''),
(229,'Fahrenheit 9/11','Michael Moore', 2004,'USA', 8, '', ''),
(230,'En un lugar de África','Caroline Link', 2001,'GERMANY', 3, '', ''),
(231,'Four Rooms','Quentin Tarantino', 1995,'USA', 5, '', ''),
(232,'Monster\'s ball','Marc Forster', 2001,'USA', 7, '', ''),
(233,'El americano impasible','Phillip Noyce', 2002,'USA', 5, '', ''),
(234,'Twister','Jan de Bont', 1996,'USA', 7, '', ''),
(235,'Titanic','Jame Cameron', 1997,'USA', 4, '', ''),
(236,'La maldición del escorpión de jade','Woody Allen', 2001,'USA', 5, '', ''),
(237,'El amante','Jean-Jacques Annaud', 1992,'FRANCE', 3, '', ''),
(238,'A.I. Inteligencia artificial','Steven Spielberg', 2001,'USA', 6, '', ''),
(239,'El río de la vida','Robert Redford', 1992,'USA', 6, '', ''),
(240,'Casa de arena y niebla','Vadim Perelman', 2003,'USA', 2, '', ''),
(241,'Los lunes al sol','Fernando León de Aranoa', 2002,'SPAIN', 6, '', ''),
(242,'El talento de Mr. Ripley','Anthony Minghella', 1999,'USA', 4, '', ''),
(243,'Gente con clase','Eric Styles', 2000,'UK', 4, '', ''),
(244,'Tres colores: Blanco','Krzysztof Kieslowski', 1994,'POLAND', 8, '', ''),
(245,'El cuchillo en el agua','Roman Polanski', 1962,'POLAND', 7, '', ''),
(246,'Buenas noches y buena suerte','George Clooney', 2005,'USA', 2, '', ''),
(247,'El Hotel New Hampshire','Tony Richardson', 1984,'UK', 4, '', ''),
(248,'Family man','Brett Ratner', 2000,'USA',  9, '', ''),
(249,'Cosas que diría con sólo mirarla','Rodrigo García', 2000,'USA', 4, '', ''),
(250,'¿Qué hace una chica com tú en un lugar como este?','Fernando Colomo', 1978,'SPAIN', 2, '', ''),
(251,'La cuadrilla','Ken Loach', 2001,'UK', 5, '', ''),
(252,'La cena de los idiotas','Francis Veber', 1998,'FRANCE', 6, '', ''),
(253,'El piano','Jane Campion', 1993,'NOVA ZELANDA', 7, '', ''),
(254,'Mi marido es una ruina','Marcello Cesena', 2001,'ITALY', 6, '', ''),
(255,'Match point','Woody Allen', 2005,'UK', 6, '', ''),
(256,'Paycheck','John Woo', 2003,'USA', 4, '', ''),
(257,'La caja china','Wayne Wang', 1997,'USA', 2, '', ''),
(258,'Siete años en el Tibet','Jean-Jacques Annaud', 1997,'USA', 9, '', ''),
(259,'El festín de Babette','Gabriel Axel', 1987,'DENMARK', 9, '', ''),
(260,'Dragon Rapide','Jaime Camino', 1986,'SPAIN', 4, '', ''),
(261,'Lolita','Stanley Kubrick', 1962,'UK', 2, '', ''),
(262,'Mi vida sin mi','Isabel Coixet', 2003,'SPAIN', 9, '', ''),
(263,'21 gramos','Alejandro González Iñárritu', 2003,'USA', 7, '', ''),
(264,'La casa de los espíritus','Bille August', 1993,'USA', 9, '', ''),
(265,'El honor de los Prizzi','John Huston', 1985,'USA', 4, '', ''),
(266,'Basic','John McTiernan', 2003,'USA', 7, '', ''),
(267,'Muerte entre las flores','Joel Coen', 1990,'USA', 2, '', ''),
(268,'Monster','Patty Jenkins', 2003,'USA', 9, '', ''),
(269,'Gente pez','Jorge Iglesias', 2001,'SPAIN',  9, '', ''),
(270,'Hombres de honor','George Tillman Jr.', 2000,'USA', 10, '', ''),
(272,'La vida de Brian','Terry Jones', 1979,'UK', 9, '', ''),
(273,'Investigating sex','Alan Rudolph', 2001,'USA', 3, '', ''),
(274,'Drácula de Bram Stoker','Francis Ford Coppola', 1992,'USA', 5, '', ''),
(275,'Moulin rouge','Baz Luhrmann', 2001,'AUSTRALIA', 6, '', ''),
(276,'Vecinos sospechosos','Tim Hunter', 1996,'USA', 7, '', ''),
(277,'Canciones para después de una guerra','Basilio Martín Patino', 1971,'SPAIN', 3, '', ''),
(278,'Le llaman Bodhi','Kathryn Bigelow', 1991,'USA', 4, '', ''),
(279,'La máscara del zorro','Martin Campbell', 1998,'USA', 2, '', ''),
(280,'La pasión de Cristo','Mel Gibson', 2004,'USA', 5, '', ''),
(281,'Un mundo perfecto','Clint Eastwood', 1993,'USA', 5, '', ''),
(282,'La boda de Muriel','P.J. Hogan', 1994,'AUSTRALIA', 2, '', ''),
(283,'Romeo + Julieta de William Shakespeare','Baz Luhrmann', 1996,'CANADA', 9, '', ''),
(284,'Chicago','Rob Marshall', 2002,'USA',4, '', ''),
(285,'Dalí','Antoni Ribas', 1991,'SPAIN', 8, '', ''),
(286,'Las reglas del juego','Roger Avary', 2002,'USA', 8, '', ''),
(287,'Cyrano de Bergerac','Jean-Paul Rappeneau', 1990,'FRANCE', 7, '', ''),
(288,'Las horas','Stephen Daldry', 2002,'USA', 3, '', ''),
(289,'Bagdad café','Percy Adlon', 1987,'GERMANY', 6, '', ''),
(290,'Italiano para principiantes','Lone Scherfig', 2000,'DENMARK', 9, '', ''),
(291,'Kate & Leopold','James Mangold', 2001,'USA', 3, '', ''),
(292,'Como agua para chocolate','Alfonso Arau', 1992,'MEXIC', 6, '', ''),
(293,'La fortuna de vivir','Jean Becker', 1998,'FRANCE', 7, '', ''),
(294,'Lost in translation','Sofia Coppola', 2003,'USA', 9, '', ''),
(295,'1492 La conquista del paraíso','Ridley Scott', 1992,'UK', 2, '', ''),
(296,'Pemonition 7 días','Mennan Yapo', 2007,'USA', 8, '', ''),
(297,'Cadena perpetua','Frank Darabont', 1994,'USA', 3, '', ''),
(298,'Los fabulosos baker boys','Steve Kloves', 1989,'USA', 4, '', ''),
(299,'Enrique V','Kenneth Branagh', 1989,'UK', 9, '', ''),
(300,'El hijo de la novia','Juan José Campanella', 2000,'ARGENTINA', 7, '', ''),
(301,'Dogville','Lars von Trier', 2003,'DENMARK', 6, '', ''),
(302,'El indomable Will Hunting','Gus Van Sant', 1997,'USA', 5, '', ''),
(303,'Desde el infierno','Albert Hughes', 2001,'USA', 10, '', ''),
(304,'Dogma','Kevin Smith', 1999,'USA', 9, '', ''),
(305,'La escopeta nacional','Luis García Berlanga', 1978,'SPAIN', 9, '', ''),
(306,'Amantes','Vicente Aranda', 1991,'SPAIN', 8, '', ''),
(307,'El extraño viaje','Fernando Fernán-Gómez', 1964,'SPAIN', 4, '', ''),
(308,'La gran familia','Fernando Palacios', 1962,'SPAIN', 2, '', ''),
(309,'La buena estrella','Ricardo Franco', 1997,'SPAIN', 6, '', ''),
(310,'Ópera prima','Fernando Trueba', 1980,'SPAIN', 3, '', ''),
(311,'Plácido','Luis García Berlanga', 1961,'SPAIN', 5, '', ''),
(312,'Mission: Impossible','Brian De Palma', 1995,'USA', 10, '', ''),
(313,'Las vírgenes suicidas','Sofia Coppola', 1999,'USA', 6, '', ''),
(314,'Celebración','Thomas Vinterberg', 1998,'DENMARK', 8, '', ''),
(315,'Valmont','Milos Forman', 1989,'UK', 10, '', ''),
(316,'El abuelo','José Luis Garci', 1998,'SPAIN', 2, '', ''),
(317,'Boca a boca','Manuel Gómez Pereira', 1995,'SPAIN', 2, '', ''),
(318,'Las normas de la casa de la sidra','Lasse Hallström', 1999,'USA', 6, '', ''),
(319,'Amelie','Jean-Pierre Jeunet', 2001,'FRANCE', 8, '', ''),
(320,'La liga de los hombres extraordinarios','Stephen Norrington', 2003,'USA', 6, '', ''),
(321,'Harry un amigo que os quiere','Dominik Moll', 2000,'FRANCE', 3, '', ''),
(322,'Mediterráneo','Gabriele Salvatores', 1991,'ITALY', 10, '', ''),
(323,'Delicatessen','Jean-Pierre Jeunet', 1991,'FRANCE', 7, '', ''),
(324,'El juego de Ripley','Liliana Cavani', 2002,'USA', 6, '', ''),
(325,'El último golpe','David Mamet', 2001,'USA', 5, '', ''),
(326,'Lolita (1997)','Adrian Lyne', 1997,'USA',  8, '', ''),
(327,'To be or not to be','Ernst Lubitsch', 1942,'USA', 10, '', ''),
(328,'9 songs','Michael Winterbottom', 2004,'UK', 3, '', ''),
(329,'Billy Elliot','Stephen Daldry', 2000,'UK', 7, '', ''),
(330,'En busca del fuego','Jean-Jacques Annaud', 1981,'CANADA', 3, '', ''),
(332,'Nadie es perfecto','Joel Schumacher', 1999,'USA', 10, '', ''),
(333,'El click','Milo Manara', 1997,'USA', 2, '', ''),
(334,'La dolce vita','Federico Fellini', 1960,'ITALY', 10, '', ''),
(335,'Ginger y Fred','Federico Fellini', 1985,'ITALY', 5, '', ''),
(336,'Oliver Twist','David Lean', 1948,'UK', 7, '', ''),
(337,'Casanova','Federico Fellini', 1976,'ITALY', 2, '', ''),
(338,'Delicias turcas','Paul Verhoeven', 1973,'HOLAND', 5, '', ''),
(339,'Rebelde sin causa','Nicholas Ray', 1955,'USA', 10, '', ''),
(340,'Casablanca','Michael Curtiz', 1942,'USA', 7, '', ''),
(341,'Psicosis','Alfred Hitchcock', 1960,'USA', 8, '', ''),
(342,'Toma el dinero y corre','Woody Allen', 1969,'USA', 5, '', ''),
(343,'La última legión','Doug Lefler', 2007,'UK', 2, '', ''),
(344,'Lejos del cielo','Todd Haynes', 2002,'USA', 10, '', ''),
(345,'El Dr. T. Y las mujeres','Robert Altman', 2000,'USA', 6, '', ''),
(346,'El hundimiento','Oliver Hirschbiegel', 2004,'GERMANY', 9, '', ''),
(347,'Trece días','Roger Donaldson', 2000,'USA', 9, '', ''),
(348,'Mulholland drive','David Lynch', 2001,'USA', 7, '', ''),
(349,'El caso wells','Wai Keung Lau', 2007,'USA', 5, '', ''),
(350,'Una habitación con vistas','James Ivory', 1985,'UK', 4, '', ''),
(351,'Falsas apariencias','Jonathan Lynn', 1999,'USA', 6, '', ''),
(352,'El banquete de boda','Ang Lee', 1993,'TAIWÀN', 3, '', ''),
(353, 'Pulp Fiction', 'Quentin Tarantino', 1994, 'USA', 9, '', ''),
(354, 'Las niñas', 'Pilar Palomero', '2020', 'SPAIN', '', ''),
(355, 'Parásitos', 'Bong Joon Ho', '2019', 'KOREA', '', ''),
(356, 'Sitara', 'Sharmeen Obaid-Chinoy', '2019', 'PAKISTAN', '', ''),
(357, 'Veneno (Miniserie TV)', 'Los Javis', '2020', 'SPAIN', '', ''),
(358, 'Close-Knit', 'Naoko Ogigami', '2017', 'JAPAN', '', ''),
(359, 'Tomboy', 'Céline Sciamma', '2011', 'FRANCE', '', ''),
(360, 'Girl', 'Lukas Dhont', '2018', 'GERMANY', '', ''),
(361, 'La chica danesa', 'Tom Hooper', '2015', 'UK', '', ''),
(362, 'Canino', 'Yorgos Lanthimos', '2009', 'GREECE', '', ''),
(363, 'Vivir sin nosotros', 'David Fardmar', '2020', 'SWEDEN', '', ''),
(364, 'El perro que no calla', 'Ana Katz', '2021', 'ARGENTINA', '', ''),
(365, 'Yo niña', 'Natural Arpajou', '2017', 'ARGENTINA', '', ''),
(366, 'La lista de Schindler', 'Steven Spielberg', '1993', 'USA', '', ''),
(367, 'Cadena perpetua', 'Frank Darabont', '1994', 'USA', '', ''),
(368, 'La vida es bella', 'Roberto Berini', '1997', 'ITALY', '', ''),
(369, 'El chico', 'Charles Chaplin', '1921', 'USA', '', ''),
(370, 'Casablanca', 'Michael Curtiz', '1942', 'USA', '', ''),
(371, 'Candilejas (Limelight)', 'Charles Chaplin', '1952', 'USA', '', ''),
(372, 'El practicante', 'Carles Torras', '2020', 'SPAIN', '', ''),
(373, 'Enola Holmes', 'Harry Bradbeer', '2020', 'USA', '', ''),
(374, 'La canción del mar', 'Tomm More', '2014', 'IRELAND', '', ''),
(375, 'Contigo a muerte', 'Ryuichi Hiroki', '2021', 'KOREA', '', ''),
(376, 'El tercero en discordia', 'Neeraj Ghaywan, Kayoze Irani, Shashank Khaitan', '2021', 'pais', '', ''),
(377, 'Monstruo (Monster)', 'Anthony Mandler', '2018', 'USA', 'observaciones', '', ''),
(378, 'La vida secreta de las palabras', 'Isabel Coixet', '2005', 'SPAIN', '', ''),
(379, 'Hacia rutas salvajes (Into the Wild)', 'Sean Penn', '2007', 'USA', '', ''),
(380, 'Her', 'Spike Jonze', '2013', 'USA', 'observaciones', '', ''),
(381, 'El resplandor', 'Stanley Kubrick', '1980', 'USA', '', ''),
(382, 'American Beauty', 'Sam Mendes', '1999', 'USA', '', ''),
(383, 'Persona', 'Ingmar Bergman', '1966', 'SWEDEN', '', ''),
(384, 'Big Fish', 'Tim Burton', '2003', 'USA', '', ''),
(385, 'Cisne negro (Black Swan)', 'Darren Aronofsky', '2010', 'USA', '', ''),
(386, 'Joker', 'Todd Phillips', '2019', 'USA', '', ''),
(387, 'Lost in Translation', 'Sofia Coppola', '2003', 'USA', '', ''),
(388, 'Las virgenes suicidas', 'Sofia Coppola', '1999', 'USA', '', ''),
(389, 'Eduardo Manostijeras', 'Tim Burton', '1990', 'USA', '', ''),
(390, 'Bin Jip (Hierro 3)', 'Kim Ki-duk', '2004', 'KOREA', '', ''),
(391, 'Psicosis', 'Alfred Hitchcock', '1960', 'USA', '', ''),
(392, 'Secretary', 'Steven Shainberg', '2002', 'USA', '', ''),
(393, 'El silencio de los corderos', 'Jonathan Demme', '1991', 'USA', '', ''),
(394, 'A silent Voice (Koe no katachi)', 'Naoko Yamada', '2016', 'JAPAN', '', ''),
(395, 'Your name (Kimi no na wa)', 'Makoto Shinkai', '2016', 'JAPAN', '', ''),
(396, 'En este rincon del mundo (Kono sekai no katasumi ni)', 'Sunao Katabuchi', '2019', 'JAPAN', '', ''),
(397, 'Mi vecino Totoro', 'Hayao Miyazaki', '1988', 'JAPAN', 'observaciones', '', ''),
(398, 'El castillo en el cielo', 'Hayao Miyazaki', '1986', 'JAPAN', 'observaciones', '', ''),
(399, 'Los niños lobo', 'Mamoru Hosoda', '2012', 'JAPAN', 'observaciones', '', ''),
(400, '5 centimetros por segundo (Byosoku go Senchimetoru )', 'Makoto Shinkai', '2007', 'JAPAN', '', ''),
(401, 'El ultimo suspiro', 'Lea Pool', '2001', 'CANADA', '', ''),
(402, 'Wonder', 'Stephen Chbosky', '2017', 'USA', '', ''),
(403, 'El lado bueno de las cosas', '', '2002', 'USA', '', ''),
(404, 'Habitación en Roma', '', '2002', 'USA', '', ''),
(405, 'La vida de Adele', '', '2013', 'USA', '', ''),
(406, 'Carol', 'Todd Haynes', '2015', 'UK', '', ''),
(407, 'El diario de Noa', '', '2004', 'USA', '', ''),
(408, 'Mi chica', '', '1991', 'USA', '', ''),
(409, 'Shakespeare in love', '', '1998', 'USA', '', ''),
(410, 'Pretty Woman', '', '1990', 'USA', '', ''),
(411, 'Shakespeare in love', '', '1998', 'USA', '', ''),
(412, 'Quiereme si te atreves', '', '2003', 'USA', '', ''),
(413, 'Tres metros sobre el cielo', '', '2004', 'USA', '', ''),
(414, 'Soul', 'Pete Docter, Kemp Powers', '2020', 'USA', '', ''),
(415, 'Cautivo del deseo', 'John Cromwell', '1934', 'USA', '', ''),
(416, 'Million Dollar Baby', 'Clint Eastwood', '2004', 'USA', '', ''),
(417, 'Amelie', 'Jean-Pierre Jeunet', '2001', 'FRANCE', '', ''),
(418, 'Requiem por un sueño', 'Darren Aronofsky', '2000', 'USA', '', ''),
(419, '¿Qué fue de Baby Jane?', 'Robert Aldrich', '1962', 'USA', '', ''),
(420, 'La habitación', 'Lenny Abrahamson', '2015', 'IRELAND', '', ''),
(421, 'La piel dura', 'François Truffaut', '1976', 'FRANCE', '', ''),
(422, 'La piel dura', 'François Truffaut', '1976', 'FRANCE', '', ''),
(423, 'Recursos inhumanos (Derapages)(Miniserie TV)', 'Ziad Doueiri', '2020', 'FRANCE', '', ''),
(424, 'El Show de Truman (The Truman Show)', 'Peter Weir', '1998', 'USA', '', ''),
(425, 'Los traductores (Les traducteurs)', 'Regis Roisard', '2019', 'FRANCE', '', ''),
(426, 'Pequeños detalles (The Little Things)', 'John Lee Hancook', '2021', 'USA', '', ''),
(427, 'El padre', 'Florian Zeller', '2020', 'UK', '', ''),
(428, 'Extraños en un tren', 'Alfred Hitchcock', '1951', 'USA', '', ''),
(429, 'La ventana indiscreta (Rear Window)', 'Alfred Hitchcock', '1954', 'USA', '', ''),
(430, 'Relic', 'Natalie Erika James', '2020', 'AUSTRALIA', '', ''),
(431, 'Nomadland', 'Chloe Zhao', '2020', 'USA', '', ''),
(432, 'Noticias del gran mundo (News of the World)', 'Paul Greengrass', '2020', 'USA', '', ''),
(433, 'Tan fuerte, tan cerca (Extremely Loud and Incredibly Close)', 'Stephen Daldry', '2011', 'USA', '', ''),
(434, 'La terminal', 'Steven Spielberg', '2004', 'USA', '', ''),
(435, 'El club de la lucha', 'Steven Spielberg', '2004', 'USA', '', ''),
(436, 'El club de los poeta muertos', 'Steven Spielberg', '2004', 'USA', '', ''),
(437, 'El diario de Ana Frank', 'Steven Spielberg', '2004', 'USA', '', ''),
(438, 'Shirley', 'Josephine Decker', '2020', 'USA', '', ''),
(439, 'Multiple', 'M. Night Shyamalan', '2016', 'USA', '', ''),
(410, 'El último crucero (The last Cruise) (Documental)', 'Hannah Olson', '2021', 'USA', '', ''),
(411, 'Cuando el viento sopla', 'Jimmy T. Murakami', '1986', 'UK', '', ''),
(412, 'Homeland (Serie TV)', 'Howard Gordon (Creador), Alex Gansa (Creador), Gideon Raff (Creador), Lesli Linka Glatter, Michael Cuesta, Daniel Attias, Clark Johnson, Keith Gordon, Alex Graves, Tucker Gates, Guy Ferland, Seith Mann, Jeffrey Nachmanoff, Carl Franklin, Michael Offer, Brad Turner, John Dahl, Lodge Kerrigan, Jeremy Podeswa, David Semel, Daniel Minahan, David Nutter, Jeffrey Reiner, Charlotte Sieling, John David Coles, Michael Klick, Nelson McCormick', '2011', 'USA', '', ''),
(413, 'Perdida (Gone Girl)', 'David Fincher', '2014', 'USA', '', ''),
(414, 'El intercambio', 'Clint Eastwood', '2008', 'USA', '', ''),
(415, 'Anorexia (S)', 'J. Prada, K. Prada', '2010', 'SPAIN', '', ''),
(416, 'Ayer no termina nunca', 'Isabel Coixet', '2013', 'SPAIN', '', ''),
(417, 'Los girasoles ciegos', 'Jose Luis Cuerda', '2008', 'SPAIN', '', ''),
(418, 'Hable con ella', 'Pedro Almodovar', '2002', 'SPAIN', '', ''),
(419, 'Nadie quiere la noche', 'Isabel Coixet', '2015', 'SPAIN', '', ''),
(420, 'Mi otro yo', 'Isabel Coixet', '2013', 'UK', '', ''),
(421, 'A los que aman', 'Isabel Coixet', '1998', 'SPAIN', '', ''),
(422, 'Cosas que nunca te dije', 'Isabel Coixet', '1996', 'SPAIN', '', ''),
(423, 'No mataras', 'David Victori', '2020', 'SPAIN', '', ''),
(424, 'Adu', 'Salvador Calvo', '2020', 'SPAIN', '', ''),
(425, 'El niño que domó el viento', 'Chiwetel Ejiofor', '2019', 'UK', '', ''),
(426, 'El niño que quería volar', 'Jorge Muriel', '2017', 'SPAIN', '', ''),
(427, 'La guerra de papá (El principe destronado)', 'Antonio Mercero', '1977', 'SPAIN', '', ''),
(428, 'El principito (Le petit prince)', 'Theo Kerp', '1990', 'FRANCE', '', ''),
(429, 'Mar adentro', 'Alejandro Amenabar', '2004', 'SPAIN', '', ''),
(430, 'Mejor imposible', 'James L. Brooks', '1997', 'USA', '', ''),
(431, 'Vivir (Ikiru)', 'Akira Kurosawa', '1952', 'JAPAN', '', ''),
(432, 'Atrapado en el tiempo / El dia de la marmota (Groundhog Day)', 'Harold Ramis', '1993', 'USA', '', ''),
(433, 'Memoria', 'Apichatpong Weerasethakul', '2021', 'TAILAND', '', ''),
(434, 'Pingpong', '', '2006', 'GERMANY', '', ''),
(435, 'Amor', 'Michael Haneke', '2012', 'AUSTRIA', '', ''),
(436, 'La cinta blanca', 'Michael Haneke', '2009', 'GERMANY', '', ''),
(437, 'Oscura inocencia (Mysterious Skin)', 'Gregg Araki', '2004', 'USA', '', ''),
(438, 'El silencio (Motus)', 'Elodie Wallace', '2020', 'FRANCE', '', ''),
(439, 'Gracias a Dios (Grace a Dieu)', 'François Ozon', '2018', 'FRANCE', '', ''),
(440, 'For my Brother (For min Brors skyld)', 'Brian Bang', '2014', 'DENMARK', '', ''),
(441, 'Las inocentes (Les inocentes)', 'Anne Fontaine', '2016', 'FRANCE', '', ''),
(442, 'El renacido (The revenant)', 'Alejandro González Iñárritu', '2015', 'USA', '', ''),
(443, 'Titanic', 'James Cameron', '1997', 'USA', '', ''),
(444, 'Revolutionary Road', 'Sam Mendes', '2008', 'USA', '', ''),
(445, 'El aviador', 'Martin Scorsese', '2004', 'USA', '', ''),
(446, 'Diario de un rebelde', 'Scott Kalvert', '1995', 'USA', '', ''),
(447, 'Vida de este chico (This Boys Life)', 'Michael Caton-Jones', '1993', 'USA', '', ''),
(448, 'La milla verde (Milagros desesperados o The Green Mile)', 'Frank Darabont', '1999', 'USA', '', ''),
(449, 'Quedate a mi lado', 'Chris Columbus', '1998', 'USA', '', ''),
(450, 'Camino', 'Javier Fesser', '2008', 'SPAIN', '', ''),

/* LISTADO DE PELICULAS QUE PODRÍAN INCLUIRSE POR SU VALOR EDUCATIVO Y EMOCIONAL


Rain Man
El bola
Cobardes (José Corbacho y Juan Cruz, 2008),
Bullying (Josetxo San Mateo, 2009),
Flor del desierto (Sherry Horman, 2009),
No tengas miedo (Montxo Armendáriz, 2011),
Polisse (Maïwen, 2011)

Corazones rasgados (Gyllenhaal Stephen, 1995),
La casa de los babys (John Sayles, 2003),
La pequeña Lola (Bertrand Tavernier, 2004),
Nordeste (Juan Solana, 2005),
Vete y vive (Radu Mihaileanu, 2005),
El niño de Marte (Menno Meyjes, 2007),
Cuando ella me encontró (Helen Hunt, 2007),
La vergüenza (David Planell, 2009)

Un sabor a miel (Tony Richardson, 1961),
Adiós cigüeña, adiós (Manuel Summers, 1971),
La que hemos armado (John G Avildsen, 1988),
La fuerza del amor (Matt Williams, 2000),
Los chicos de mi vida (Penny Marshall, 2001),
Palíndromos (Tod Solonz, 2004),
Juno (Jason Reitman, 2007),
El mejor (Shana Feste, 2009),
Precious (Lee Daniels, 2009)

Mi pie izquierdo (Jim Sheridan, 1989),
Las llaves de la casa (Gianni Amelio, 2004), etc.

 XXY (Luisa Puenzo, 2007),
 El último verano de la boyita (Julia Solomonoff, 2009), etc.

Cartas a Dios (Éric-Emmanuel Schmitt, 2009). Francia, Bélgica y Canadá
El llanto de la mariposa (Frank Strecker, 1999). Alemania
La decisión de Anne (Nick Cassavetes, 2009). Estados Unidos
Pequeña Miss Sunshine
La última nieve de primavera (Raimondo del Balzo, 1973)
Maktub (Paco Arango, 2011). España
Surviving Amina (Bárbara Celis, 2010). España y Estados Unidos
Un paseo para recordar (Adam Shankman, 2002). Estados Unidos
Vivir para siempre (Gustavo Ron, 2010). España
Cartas al cielo (Patrick Doughtie y David Nixon, 2010). Estados Unidos
La mariposa azul. En busca de un sueño. (Léa Pool, 2004). Canadá
Planta 4ª (Antonio Mercero, 2003). España
Restless (Gus Van Sant, 2011). Estados Unidos
Magical girl
50/50
Una mente maravillosa
Bajo la misma estrella
Ma ma
Jarabe contra el cáncer
100 metros
Arrugas
Siempre Alice (Still Alice)
Lala y Lola
Amor y otras drogas (Love and other drugs)
Lo mejor de mi
El regalo
Undfriended
Un monstruo viene a verme
Moonlight
Cyberbully Ben Chanan 2015 UK
Karate Kid
Bully
Amigas hasta la muerte (Odd Girl Out) 2005
Una chica como ella (A girl like her) 2005
Después de Lucia Michel Franco 2012
El país del miedo
Fuerte Apache
Audrie and Daisy
No tengas miedo
Princesa Lee Su-Jin 2015
Precious Lee Daniels 2009
Un dios salvaje Roman Polanski 2011
Elephant Gus Van Sant 2003
Carrie Brian de Palma 1976
Klass Ilmar Raag 2007
Dejame entrar Matt Reeves 2010
Todo sobre Lily Shunji Iwai 2001
Ben X Nic Balthazar 2007

Criadas y señoras Tate Taylor 2011
La bicicleta verde Haifaa Al Mansour 2012
Thelma y Louise Ridley Scott (1991)

Naufrago Robert Zemeckis 2000
Cadena perpetua Frank Darabont 1994
En busca de la felicidad Gabriele Muccino 2006
Mulan Tony Bancroft, Barry Cook 1998
Brave Mark Andrews, Steve Purcell, Brenda Chapman 2012
El castillo ambulante Hayao Miyazaki 2004
Cadena de favores Mimi Leder 2000
Un dia sin fin
Wit

Detective Downs
Buddies
El cazador de sueños
Ghadi

This Close (2020)
El milagro de Anna Sullivan” (EEUU, 1962)
“A quiet place” (EEUU, 2018)
La familia Bélier” (Francia, 2014)
“El corazón es un cazador solitario” (EEUU, 1968)
Plemya [The Tribe], película ucraniana de 2014. Muy especial debido a que, aunque con sonido ambiente, no tiene banda sonora, no tiene subtítulos y es íntegramente en lengua de signos. No he visto otra igual. El espectador está obligado a verla desde el punto de vista de un sordo, solo puede entender lo que ve, no hay sonido ni hablado ni musical, tan solo los ruidos ambientes y los que emiten los personajes sordos. Recuerdo que, cuando la vi en el Festival de Cine Europeo de Sevilla, hubo gente que se marchó de la sala. También es dura de ver ya que subyace una violencia evidente en las vidas que se muestran, en ocasiones también bastante explícita, pero es un ejercicio cinematográfico sobre el mundo del sordo (muy específico, en una especie de escuela o internado de una Ucrania bastante sórdida) que nunca antes he visto, aunque es cierto que para nada representa a la persona sorda. Brutal, cruda.

Triunfo a la Vida.( Mr. Holland Opus) 1995. No es el tema central pero si lo aborda.
 1952…MANDY. Es sobre una niña sorda. Vale la pena.
 Un lugar tranquilo (2018)
 Las normas de la casa de la sidra
Serena 2014
Con amor, Simon (2018)
El hilo invisible (2018)
El discurso del rey (2010)
Bohemian Rhapsody 2018
La teoría del todo (2015)
Vita y Virginia (2020)
Judy (2019)
La chica danesa (2016)
Alicia en el país de las maravillas (2010)
El hombre invisible 2020
Dejame salir 2017
Gambito de Dama (Serie TV)
El sótano de Ma
La chica del tren (2016)
El muñeco de nieve (2017)
La montaña entre nosotros 2017
A la deriva 2018
Identidad borrada 2019
Que fue de Brad 2017
¿Dónde estas Bernadette 2020
The Mauritanian 2021
Toda la verdad 2016
Spotlight 2016
Lion (2016)
Tambien la lluvia (2011)
La flor de mi secreto (1995)
La última llamada 2013
Gothika 2004
Perturbada 2018
Figuras ocultas 2017
Loving
El profesor 2011
Little Fish
Su último Deseo
El último suspiro
Vidas de papel
Desplazados
Solo
Hasta los huesos
El autor
Steven
Forest Gump
invisible
Birdman 2015
El castillo de cristal 2017
Alma salvaje 2015
Babel (2006)
Hanna 2011
Matrix 1999
AI Inteligencia Artificial
La naranja mecánica 1975
Millenium 2012
El resplandor
Zodiac 2007
Stalker 1979
The sacrifice 1986
Nostalgia 1983
El espejo Tarkovsky
Solaris Tarkovsky


 */


--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `pellicules_txt_3`
--
ALTER TABLE 'psicopelis'
  ADD PRIMARY KEY ('id');

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `pellicules_txt_3`
--
ALTER TABLE 'psicopelis'
  MODIFY 'id' int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=354;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
