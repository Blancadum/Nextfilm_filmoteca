<html lang="en">
<head>
<meta charset="UTF-8">
<!--tema responsive-->
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!--Favicon-->
<link href="../img/favicon.png" rel="icon" type="image/png" />

<!--Archivo CSS externo -->
<link rel="stylesheet" href="../css/style.css" type="text/css"/>

<!--Google fonts-->
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">

<title>NextFilm</title>

</head>

<body>
	<div class="slider">
		<p> < Esto será un slider > </p>
	</div>
<!--- CABECERA DE NEXTFILM ------------------------------------>
<header>
<!--<div class="slider"><img src="img/slider.jpg" class="slider"/> </div>-->
<!---NEXTFILM: esto es lo que será específico para cada página------------------------>
<div class="h2">
		<h2 class="logotipo">NEXTFILM</h2>
</div>

<div class="nav">
	<nav>
		<a href="../index.php#titulo">Home</a>
		<a href="../buscar/buscar.php#titulo">Buscar</a>
		<a href="../agregar/agregar.php#titulo">Agregar</a>
		<a href="../editar/editar.php#titulo">Editar</a>
		<a class="activo">Eliminar</a>
		<a href="../sobreNF/leeme.php#titulo">Sobre NextFilm</a>
	</nav>

</div>
</header>
<!-- Termina el header -->
<hr class="separador-animado100"></hr>
<!---NEXTFILM: esto es lo que será específico para cada página------------------------>
<main>
<!--EMPIEZA LA PRIMERA SECCIÓN DE LA PÁGINA -->
<section class="primera">
	<article class="introduccion">
		<!--EMPIEZA EL ARTICULO DE LA INTRODUCCIÓN DE LA PAGINA-->
		<div class="contenido-principal">
			<h3 class="titulo">Eliminar películas </h3>
				<p class="descripcion">Estás aquí porque no puedes ni ver algunos de los 'films' que tenemos en catálogo. Venga, desahógate y bórralos. Pero recuerda que si los borras, ¡será para siempre!</p>
				<br>
			<!-- botones -->
				<a href="eliminar.php#formulario"> <button role="button" class="boton" ><i class="fas fa-play"></i>Tengo instinto asesino!</button></a>
				<a href="eliminar.php#documentacion"> <button role="button" class="boton"><i class="fas fa-info-circle" ></i>Cuéntame más!</button></a>
				<br>
				<br>
			<hr class="separador-animado70"></hr>
		</div>


	</article>

	<!--EMPIEZA EL ARTICULO DONDE ESTÁ EL FORMULARIO PARA ELIMINAR LAS PELICULAS-->
	<article class="formulario">
		<div class="contenido-formulario">
			<h3 class="formulario">Da rienda suelta al instinto asesino! </h3>
				<p class="descripcion"> Necesitas eliminar de la faz de la tierra esa película que te trae por el camino de la amargura!  </p>
		</div>

		<div class="resultados-formulario"> </div>
		<hr class="separador-animado70"></hr>
	</article>

<!--EMPIEZA EL ARTICULO DONDE ESTÁ LA DOCUMENTACIÓN DE ESTA ACCIÓN, aunque hay una página dedicada a ello, donde se incrusta un pdf explicativo para usuario básico y otro pdf para usuario técnico-->
	<article class="documentacion">
		<div class="contenido-principal">
			<h3 class="documentacion"> ¿Cómo se eliminan las películas? </h3>
				<p class="descripcion"> Es muy sencillo, aquí irá la parte del pdf de documentación destinada a describir cómo se eliminan. </p>
		<hr class="separador-animado70"></hr>
		</div>
	</article>
<!--TERMINA LA PRIMERA SECCIÓN DE LA PÁGINA -->
<!--POR SI LE QUIERO PONER MÁS SECCIONES A LA PÁGINA -->
</section>
</main>

<!--CODIGOS JS (ANTES DE CERRAR DE FOOTER) ------------------------------------>
<script src="https://kit.fontawesome.com/2c36e9b7b1.js" crossorigin="anonymous"></script>
<script src="js/main.js"></script>
<!--EMPIEZA EL FOOTER DE NEXTFILM ------------------------------------>
<footer>
	<div class="footer">
		<hr class="separador-animado100"></hr>
		<p class="footer"> Una web un poco loca creada por Blanca, de<a href="https://trabajofinal.es" target="_blank"> TrabajoFinal.es</a><a href="https://trabajofinal.es" target="_blank"><img src="../img/trabajofinal-logo.png"/></a><br>Gracias a Roger y a mis compis del curso de Desarrollo de Aplicaciones Web!</p>
	</div>
</footer>
<!--AQUI TERMINA FOOTER ------------------------------------>
</body>
<!--AQUI TERMINA BODY ------------------------------------>
</html>
