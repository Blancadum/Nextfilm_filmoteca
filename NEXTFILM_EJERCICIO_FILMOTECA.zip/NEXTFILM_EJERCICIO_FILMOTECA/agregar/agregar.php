<html lang="en">
<head>
<meta charset="UTF-8">
<!--tema responsive-->
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!--Favicon-->
<link href="../img/favicon.png" rel="icon" type="image/png"/>

<!--Archivo CSS externo -->
<link rel="stylesheet" href="../css/style.css" type="text/css"/>
<!--Google fonts-->
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">

<title>NextFilm</title>
</head>
<body>
<hr class="separador-animado"></hr>
	<div class="slider">
	<p> < Esto será un slider > </p>
	</div>
<!--- CABECERA DE NEXTFILM ------------------------------------>
<header>
<!--<div class="slider"><img src="img/slider.jpg" class="slider"/> </div>-->
<!---NEXTFILM: esto es lo que será específico para cada página------------------------>
<div class="h2">
	<h2 class="logotipo">NEXTFILM</h2>
</div>

<div class="nav">
	<nav>
		<a href="../index.php#titulo">Home</a>
		<a href="../buscar/buscar.php#titulo">Buscar</a>
		<a class="activo">Agregar</a>
		<a href="../editar/editar.php#titulo">Editar</a>
		<a href="../eliminar/eliminar.php#titulo">Eliminar</a>
		<a href="../sobreNF/leeme.php#titulo">Sobre NextFilm</a>
	</nav>
</div>

</header>

<!---NEXTFILM: esto es lo que será específico para cada página------------------------>
<main>
<section>
	<article class="introduccion">
		<div class="contenido-principal">
			<h3 class="titulo">¿Quieres añadir una película a la base de datos?</h3>
			<p class="descripcion"> <b>Cuatro ojos ven más que dos ¡nunca mejor dicho! Por eso, te invito a añadir tooodas las películas que consideres deberían estar en el catálogo de NextFilm! ¿Te hace?</p>
				<br>
				<br>
						<a href="agregar.php#formulario"><button role="button" class="boton"><i class="fas fa-play"></i>¡Sí, claro que me hace!</button></a>
						<a href="agregar.php#documentacion">	<button role="button" class="boton"><i class="fas fa-info-circle"></i>Cuéntame más!</button></a>
				</br>
				</br>
			<hr class="separador-animado70"></hr>
		</div>
	</article>

<!--Empieza el artículo sobre el formulario para agregar ------------------------------------>
	<article class="formulario">

		<div class="contenido-formulario">
			<h3 class="formulario"> Porque todo suma... </h3>
			<p class="descripcion">
		</div>

		<div class="resultados-formulario">

		</div>
		<hr class="separador-animado70"></hr>

	</article>
<!--Empieza el artículo sobre la documentación ------------------------------------>
	<article class="documentacion">
		<div class="contenido-principal">
			<h3 class="documentacion"> </h3>
			<p class="descripcion">  </p>
			<hr class="separador-animado"></hr>
		</div>
	</article>

</section>
</main>
<!-- CODIGOS JS (ANTES DE CERRAR DE FOOTER) ------------------------------------>
<script src="https://kit.fontawesome.com/2c36e9b7b1.js" crossorigin="anonymous"></script>
<script src="js/main.js"></script>
<!--EMPIEZA EL FOOTER DE NEXTFILM ------------------------------------>
<footer>
	<div class="footer">
		<hr class="separador-animado100"></hr>
			<p class="footer"> Una web un poco loca creada por Blanca, de<a href="https://trabajofinal.es" target="_blank"> TrabajoFinal.es</a><a href="https://trabajofinal.es" target="_blank"><img src="../img/trabajofinal-logo.png"/></a><br>Gracias a Roger y a mis compis del curso de Desarrollo de Aplicaciones Web! </p>
	</div>
</footer>
<!--AQUI TERMINA FOOTER ------------------------------------>
</body>
<!--AQUI TERMINA BODY ------------------------------------>
</html>
