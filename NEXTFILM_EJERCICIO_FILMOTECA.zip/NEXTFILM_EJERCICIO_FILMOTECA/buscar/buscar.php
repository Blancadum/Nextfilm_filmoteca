<html lang="en">
<head>
<meta charset="UTF-8">
<!--tema responsive-->
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!--Favicon-->
<link href="../img/favicon.png" rel="icon" type="image/png" />
<!--Archivo CSS externo -->
<link rel="stylesheet" href="../css/style.css" type="text/css"/>
<!--Google fonts-->
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">

<title>NextFilm</title>
</head>

<body>
	<div class="slider">
		<p> < Esto pretende ser un slider > </p>
	</div>
<!--- CABECERA DE NEXTFILM ------------------------------------>
<header>
<!--<div class="slider"><img src="img/slider.jpg" class="slider"/> </div>-->
<!---NEXTFILM: esto es lo que será específico para cada página------------------------>
<div class="h2">
		<h2 class="logotipo">NEXTFILM</h2>
</div>
<!--UN DIV PARA EL NAV, QUE CONTIENE EL MENU PRINCIPAL-->
<div class="nav">
	<nav>
		<a href="../index.php#titulo">Home</a>
		<a class="activo">Buscar</a>
		<a href="../agregar/agregar.php#titulo">Agregar</a>
		<a href="../editar/editar.php#titulo">Editar</a>
		<a href="../eliminar/eliminar.php#titulo">Eliminar</a>
		<a href="../sobreNF/leeme.php#titulo">Sobre NextFilm</a>
	</nav>
	</div>
</header>

<hr class="separador-animado100"></hr>
<!---NEXTFILM: esto es lo que será específico para cada página------------------------>
<!---NEXTFILM: esto es lo que será específico para cada página------------------------>
<main>
<section class="primera">
<!--ARTICULO SOBRE INTRODUCCION!-->
	<article class="introduccion">
		<div class="contenido-principal">
			<h3 class="titulo">Buscar una peli</h3>
				<p class="descripcion"> Estás aquí porque necesitas encontrar esa película que quieres ver right now! pero, hosti tú, no te acuerdas ni del título completo, ni del director...! Hace mogollón que no la ves y te deshaces en deseos por encontrarla... bah! qué cabeza la tuya... Bueno, ¡que no cunda el pánico! Quizás, si introduces algunas palabras clave en nuestro buscador, darás con ella! ¿Te animas?</p>
					<br>
					<br>
					<button role="button" class="boton"><i class="fas fa-play"></i>¡Claro que me animo!</button>
					<button role="button" class="boton"><i class="fas fa-info-circle"></i>No entiendo muy bien, cuéntame más!</button>
					</br>
					</br>
		<hr class="separador-animado70"></hr>
		</div>
	</article>
<!--ARTICULO SOBRE FORMULARIO!-->
	<article class="formulario">
		<div class="contenido-formulario">
			<h3 class="formulario"> Formulario de búsqueda </h3>
			<p class="descripcion"> Aquí tienes el formulario para buscar. ¿Por dónde empezamos? ¡Tú mandas! </p>
		<hr class="separador-animado"></hr>
		</div>

		<div class="resultados-formulario">
		</div>

	</article>
<!--ARTICULO SOBRE DOCUMENTACIÓN!-->
	<article class="documentacion">
		<div class="contenido-principal">
			<h3 class="documentacion"> ¿Cómo se busca una película en esta web? </h3>
			<p class="descripcion">  </p>
			<hr class="separador-animado70"></hr>
		</div>
	</article>
<!--TERMINA LA SECCION PRIMERA-->
</section>
</main>
<!--CODIGOS JS (ANTES DE CERRAR DE FOOTER) ------------------------------------>
<script src="https://kit.fontawesome.com/2c36e9b7b1.js" crossorigin="anonymous"></script>
<script src="js/main.js"></script>
<!--EMPIEZA EL FOOTER DE NEXTFILM ------------------------------------>
<footer>
	<div class="footer">
		<hr class="separador-animado100"></hr>
		<p class="footer"> Una web un poco loca creada por Blanca, de<a href="https://trabajofinal.es" target="_blank"> TrabajoFinal.es</a><a href="https://trabajofinal.es" target="_blank"><img src="../img/trabajofinal-logo.png"/></a><br>Gracias a Roger y a mis compis del curso de Desarrollo de Aplicaciones Web!</p>
	</div>
</footer>
<!--AQUI TERMINA FOOTER ------------------------------------>
</body>
<!--AQUI TERMINA BODY ------------------------------------>
</html>
