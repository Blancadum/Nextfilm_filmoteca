<html lang="en">
<head>
<meta charset="UTF-8">
<!--tema responsive-->
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!--Favicon-->
<link href="../img/favicon.png" rel="icon" type="image/png" />

<!--Archivo CSS externo -->
<link rel="stylesheet" href="../css/style.css" type="text/css"/>

<!--Google fonts-->
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">

<title>NextFilm</title>

</head>

<body>
	<hr class="separador-animado100"></hr>

	<div class="slider">
		<p> < Esto será un slider > </p>

	</div>
<!--- CABECERA DE NEXTFILM ------------------------------------>
<header>
<!--<div class="slider"><img src="img/slider.jpg" class="slider"/> </div>-->
<!---NEXTFILM: esto es lo que será específico para cada página------------------------>
<div class="h2">
		<h2 class="logotipo">NEXTFILM</h2>
</div>

<div class="nav">
	<nav>
		<a href="../index.php#titulo">Home</a>
		<a href="../buscar/buscar.php#titulo">Buscar</a>
		<a href="../agregar/agregar.php#titulo">Agregar</a>
		<a class="activo">Editar</a>
		<a href="../eliminar/eliminar.php#titulo">Eliminar</a>
		<a href="../sobreNF/leeme.php#titulo">Sobre NextFilm</a>
	</nav>

	</div>

</header>
<!---NEXTFILM: esto es lo que será específico para cada página------------------------>
<!---NEXTFILM: esto es lo que será específico para cada página------------------------>
<main>

<!--EMPIEZA LA PRIMERA SECCIÓN DE LA PÁGINA -->
<section class="primera">

<!--EMPIEZA EL ARTICULO DE LA INTRODUCCIÓN DE LA PAGINA-->
	<article class="introduccion">
		<div class="contenido-principal">
			<h3 class="titulo">Editar películas </h3>
				<p class="descripcion"> Trabajo cooperativo, de eso se trata. Anímate a añadir o eliminar las películas que consideres...o, si lo prefieres, también puedes cambiarle la puntuación a aquellas películas que creas que podrían estar valoradas por encima o por debajo de la puntuación que ya tienen... siéntete libre para hacer y deshacer lo que quieras.</p>
				<br>
				<br>
					<a href="editar.php#formulario"><button role="button" class="boton"><i class="fas fa-play"></i>Vamos a editar</button>
						<a href="editar.php#documentacion">	<button role="button" class="boton"><i class="fas fa-info-circle"></i>Cuéntame más</button>
				<br>
				<br>

			<hr class="separador-animado70"></hr>
		</div>

	</article>

<!--EMPIEZA EL ARTICULO DONDE ESTÁ EL FORMULARIO PARA EDITAR LAS PELICULAS-->
	<article class="formulario">

		<!--div para el formulario -->
		<div class="contenido-formulario">
			<h3 class="formulario"> ¿Cómo se editan las películas? </h3>
				<p class="descripcion"> Ahora que puedes, haz de este catálogo un mundo mejor donde vivir! </p>
				<br>
				<form class="contenido-formulario" method="get" action="">	</form>
				<br>
				<br>
				<div class="resultados-formulario">	</div>
		<hr class="separador-animado70"></hr>
		</div>

		<!--div para los resultados del formulario -->
		<div class="resultado">
		</div>
	</article>

	<!--EMPIEZA EL ARTICULO DONDE ESTÁ LA DOCUMENTACIÓN DE ESTA ACCIÓN, aunque hay una página dedicada a ello, donde se incrusta un pdf explicativo para usuario básico y otro pdf para usuario técnico-->
	<article class="documentacion">
		<div class="contenido-principal">
			<h3 class="documentacion"> ¿Cómo se editan las películas en NextFilm? </h3>
				<p class="descripcion">  </p>
		</div>

		<div class="boton-documentacion"> <p> Aquí iría el botón que enlaza a la sección de <a href="../sobreNF/leeme.php#titulo"> Documentación </a> </p>
		</div>

		<hr class="separador-animado70"></hr>
	</article>
	<!--TERMINA LA SECCIÓN PRIMERA DE LA PÁGINA -->
	</section>

	</main>

<!--CODIGOS JS (ANTES DE CERRAR DE FOOTER) ------------------------------------>
	<script src="https://kit.fontawesome.com/2c36e9b7b1.js" crossorigin="anonymous"></script>
	<script src="js/main.js"></script>
	<!--EMPIEZA EL FOOTER DE NEXTFILM ------------------------------------>

<footer>
	<div class="footer">
		<hr class="separador-animado100"></hr>
		<p class="footer"> Una web un poco loca creada por Blanca, de<a href="https://trabajofinal.es" target="_blank"> TrabajoFinal.es</a><a href="https://trabajofinal.es" target="_blank"><img src="../img/trabajofinal-logo.png"/></a><br>Gracias a Roger y a mis compis del curso de Desarrollo de Aplicaciones Web!</p>
	</div>
</footer>

<!--AQUI TERMINA FOOTER ------------------------------------>
</body>
<!--AQUI TERMINA BODY ------------------------------------>
</html>
