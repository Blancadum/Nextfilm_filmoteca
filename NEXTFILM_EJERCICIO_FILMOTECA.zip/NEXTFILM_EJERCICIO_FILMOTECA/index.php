<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<!--tema responsive-->
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!--Favicon-->
<link href="/img/favicon.png" rel="icon" type="image/png"/>

<!--Archivo CSS externo -->
<link rel="stylesheet" href="css/style.css" type="text/css"/>

<!--Google fonts-->
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">

<title>NextFilm</title>

</head>
<!--- termina head ------------------------------------>
<body>
	<div class="slider">
		<p class="descripcion"> < Esto será un slider > </p>
	</div>
<!--- CABECERA DE NEXTFILM ------------------------------------>
<header>
<!--<div class="slider"><img src="img/slider.jpg" class="slider"/> </div>-->
<!---NEXTFILM: esto es lo que será específico para cada página------------------------>
	<div class="h2">
		<h2 class="logotipo">NEXTFILM</h2>
	</div>

	<div class="nav">
		<nav>
			<a class="activo">Home</a>
			<a href="buscar/buscar.php#titulo">Buscar</a>
			<a href="agregar/agregar.php#titulo">Agregar</a>
			<a href="editar/editar.php#titulo">Editar</a>
			<a href="eliminar/eliminar.php#titulo">Eliminar</a>
			<a href="sobreNF/leeme.php#titulo">Sobre NextFilm</a>
		</nav>
	</div>

</header>
<hr class="separador-animado100"></hr>
<br>
<!---NEXTFILM: esto es lo que será específico para cada página------------------------>
<!---NEXTFILM: esto es lo que será específico para cada página------------------------>
<main>

<section class="primera">
	<!--EMPIEZA LA PRIMERA SECCIÓN DE LA PÁGINA -->
	<article class="introduccion">
		<!--EMPIEZA EL ARTICULO DE LA INTRODUCCIÓN DE LA PAGINA-->
		<div class="iframe">
			<p class="descripcion"> Idea para el futuro... </p>
			<iframe width="300" src="https://www.youtube.com/embed/bNtjCertEGI" title="Una nota para el futuro de NextFilm" frameborder="2" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
		</div>

		<div class="contenido-principal">
			<h3 class="titulo">El cine inteligente</h3>
				<p class="descripcion">Ay, diosito, escoger películas... <img class="emoji" src="img/cry.png"/> otra vez, no. El poco tiempo libre que tienes vale oro, por eso mismo, déjate de historias y disfruta del cine inteligente desde ahora mismo con esta nueva plataforma. Nextfilm aplica un algoritmo inteligente de manera que averiguará qué carajos quieres ver con solo analizar tu pupila. <br> En realidad, nada de esto es cierto pero puedes leer más sobre este proyecto clicando ¡abajo!.</p>

				<a href=""><button role="button" class="boton"><i class="fas fa-play"></i>Registro y login</button></a>
				<a href="sobreNF/leeme.php#titulo"><button role="button" class="boton"><i class="fas fa-play"></i>Cuéntame más!</button></a>

		<hr class="separador-animado70"></hr>
		</div>

		<div class="contenido-principal">
			<h4 class="listando">Listando películas</h4>
			<p class="descripcion"> Échale un ojo a nuestro catálogo! </p>
		<hr class="separador-animado70"></hr>
		</div>

	</article>

	<article class="documentacion">
<!--EMPIEZA EL ARTICULO DONDE ESTÁ LA DOCUMENTACIÓN DE ESTA ACCIÓN, aunque hay una página dedicada a ello, donde se incrusta un pdf explicativo para usuario básico y otro pdf para usuario técnico-->
		<div class="contenido-principal">
			<h4 class="documentacion"> ¿Cómo se eliminan las películas? </h4>
			<p class="descripcion"> Es muy sencillo, aquí irá la parte del pdf de documentación destinada a describir cómo se eliminan. </p>
		<hr class="separador-animado70"></hr>
		</div>
	</article>
<!--TERMINA LA PRIMERA SECCIÓN DE LA PÁGINA -->
<!--POR SI LE QUIERO PONER MÁS SECCIONES A LA PÁGINA -->
</section>
</main>
<!--CODIGOS JS (ANTES DE CERRAR DE FOOTER) ------------------------------------>
<script src="https://kit.fontawesome.com/2c36e9b7b1.js" crossorigin="anonymous"></script>
<script src="js/main.js"></script>
<!--EMPIEZA EL FOOTER DE NEXTFILM ------------------------------------>
<footer>
	<div class="footer">
		<hr class="separador-animado100"></hr>
		<p class="footer"> Una web un poco loca creada por Blanca, de<a href="https://trabajofinal.es" target="_blank"> TrabajoFinal.es</a><a href="https://trabajofinal.es" target="_blank"><img class="TFicon" src="img/trabajofinal-logo.png"/></a><br>Gracias a Roger y a mis compis del curso de Desarrollo de Aplicaciones Web!</p>
	</div>
</footer>
<!--AQUI TERMINA FOOTER ------------------------------------>
</body>
<!--AQUI TERMINA BODY ------------------------------------>
</html>
