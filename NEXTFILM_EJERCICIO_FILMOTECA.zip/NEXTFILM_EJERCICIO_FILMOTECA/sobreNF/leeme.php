<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="UTF-8">
<!--tema responsive-->
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!--Favicon-->
<link href="../img/favicon.png" rel="icon" type="image/png" />
<!--Archivo CSS externo -->
<link rel="stylesheet" href="../css/style.css" type="text/css"/>

<!--Google fonts-->
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">

<title>NextFilm</title>

</head>
<body>
	<hr class="separador-animado"></hr>
	<div class="slider">
		<p> < Esto será un slider > </p>
	</div>
<!--- CABECERA DE NEXTFILM ------------------------------------>
<header>
<!--<div class="slider"><img src="img/slider.jpg" class="slider"/> </div>-->
<!---NEXTFILM: esto es lo que será específico para cada página------------------------>
<div class="h2">
		<h2 class="logotipo">NEXTFILM</h2>
</div>
<div class="nav">
	<nav>
		<a href="../index.php#titulo">Home</a>
		<a href="../buscar/buscar.php#titulo">Buscar</a>
		<a href="../agregar/agregar.php#titulo">Agregar</a>
		<a href="../editar/editar.php#titulo">Editar</a>
		<a href="../eliminar/eliminar.php#titulo">Eliminar</a>
		<a class="activo">Sobre NextFilm</a>
	</nav>
	</div>
</header>
<!---NEXTFILM: esto es lo que será específico para cada página------------------------>
<!---NEXTFILM: esto es lo que será específico para cada página------------------------>
<main>

<section class="primera">

	<article class="introduccion">

		<div class="contenido-principal">
			<h3 class="titulo">Sobre NextFilm: Sus orígenes</h3>
				<p class="descripcion"> ¿Sientes curiosidad por el origen de esta filmoteca? Estás en el sitio idóneo. ¡Sigue leyendo! </p>
					<a href="../index.php#titulo"><button role="button" class="boton"><i class="fas fa-play"></i>Volver a la Home </button> </a>
					<a href=""><button role="button" class="boton"><i class="fas fa-info-circle"></i>Puntuar web</button> </a>
					<br>
					<br>
				<p class="descripcion"> Realmente, todo surgió cuando el profe Roger nos propuso un proyecto por "fascículos", para practicar la conexión con una base de datos con MySql: una filmoteca. Hasta aquí, bien. Pero, la verdad, me están pasando cosas y yo, en vez de "por fascículos", no me ha quedado otra que hacerlo todo en un finde. <br> Pero que no cunda el pánico... aún estoy "en ello". ¿Saldremos de esta? ¡Seguro! </p>

			<h4> Una web con proyección de futuro </h4>
				<p class="descripcion"> Antes que nada, hace unos meses empecé una web dirigida a estudiantes de último año del Grado de Psicología que están inmersos en la realización del proyecto final de carrera...Estoy hablando de <a href="https://trabajofinal.es"> Trabajo Final </a>. A raíz de la genialidad del proyecto de La Filmoteca, se me ha ocurrido que podría ser una buena idea aplicar esta propuesta a mi proyecto de "base". De manera que ese alumnado que saliera estresado de la web, después de horas investigando para su proyecto final de carrera, pudiera tirarse de cabeza a una Filmoteca específica que, además de servir como entretenimiento, le aportara algo. La cuestión es "¿qué aportaría?".
				<br> Bien, como muchos y muchas podréis imaginar, los estudiantes de último año no han podido cursar sus prácticas en el ámbito clínico con normalidad, debido a la pandemia. El miedo al contagio y las dificultades de algunos terapeutas a la hora de adaptar sus servicios presenciales a la terapia virtual, ha supuesto una reducción drástica de las horas de atención disponibles (sin contar la inmensa cantidad de usuarios que cancelaban sus citas). También la reducción del aforo en sitios cerrados ha traído consecuencias: sin dudarlo, aquí, los estudiantes prácticos han sido los primeros en ser apartados del encuadre psicológico: sobraban, no eran imprescindibles.
				<br>
			<h4> ¿Podrán las películas aportar algo al ámbito de la Psicología Clínica?</h4>
				<p class="descripcion"> Alguno o alguna aún se preguntará qué tendría que ver la filmoteca a la hora de sustituir unas prácticas curriculares en el ámbito clínico y de intervención o de la salud mental... Pues a quien lee le gustará saber que el cine se entremezcla con la psicología en cada frame. El método Stanislaski, la dramaturgia de Goffman, la conexión entre el actor y el personaje... Las artes escénicas hablan de emoción y las historias que se cuentan entre guiones y bambalinas bien podrían resultar en una terapia para alguien con algún trauma o con la necesidad de aprender de la vida cuando la vida no se deja o si se escapa entre los dedos. <br> De igual manera que una persona enferma de cáncer que no puede salir a la calle por su sistema inmunológico pero sí puede vivir a través otras historias. Y es, gracias a un elenco de personajes que entran en casa gracias a la pantalla, a tejer los recuerdos que no puede elaborar por sus circunstancias; también es un regalo cuando, ante nosotros, un personaje con un perfil psicológico interesante o con una vida difícil pero con muchas ganas, nos inspira, como personas o profesionales, para ver la vida desde otra perspectiva, hasta el momento, inabarcada.
				<br> De igual manera que pasaría cualquier cosa parecida las mencionadas, el análisis de las historias, los personajes y los perfiles retratados en las películas, nos puede ayudar a quienes no pudimos hacer aquellas ansiadas prácticas en clínica, a causa de la crisis sanitaria. <br> Surge, en este detalle, el germen que hizo brotar la idea de <a href="https://peliculasdepsicologia.es"> Películas de Psicología </a>, pensada para aunar y compartir la opinión y la crítica que quieran los estudiantes, libremente, aportar sobre las películas que se aporten. Pero no solo eso, sino que nace con un halo de esperanza de que sirva, no solo hasta que todo se solucione de una vez por todas (y dejemos de llevar mascarillas...), sino que se haya quedado para siempre, entendiendo que la Psicología es un servicio que debería ser Universal y gratuita. Normalizarla empieza por comprender que las emociones son importantes en nuestras vidas y que, como personas, somos vulnerables sin prevención y psicoeducación.
				<br></p>
		</div>

	</article>

</section>
</main>
<!-- CODIGOS JS (ANTES DE CERRAR DE FOOTER) ------------------------------------>
<script src="https://kit.fontawesome.com/2c36e9b7b1.js" crossorigin="anonymous"></script>
<script src="js/main.js"></script>
<!--EMPIEZA EL FOOTER DE NEXTFILM ------------------------------------>
<footer>
	<div class="footer">
		<hr class="separador-animado"></hr>
		<p class="footer"> Una web un poco loca creada por Blanca, de<a href="https://trabajofinal.es" target="_blank"> TrabajoFinal.es</a><a href="https://trabajofinal.es" target="_blank"><img src="../img/trabajofinal-logo.png"/></a><br>Gracias a Roger y a mis compis del curso de Desarrollo de Aplicaciones Web!</p>
	</div>
</footer>
<!--AQUI TERMINA FOOTER ------------------------------------>
</body>
<!--AQUI TERMINA BODY ------------------------------------>
</html>
